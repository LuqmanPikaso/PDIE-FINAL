from django.db import models

class StudentUserLogin(models.Model):
    StudID = models.TextField(max_length=225, primary_key=True, default='')
    StudPassword = models.CharField(max_length=15, null=True)
    StudName = models.TextField(max_length=225, null=True)    

class LecturerUserLogin(models.Model) :
    LectID = models.TextField(max_length=225, primary_key=True, default='')
    LectName = models.TextField(max_length=225, null=True)
    LectPassword = models.CharField(max_length=15)

class PerdiqmaMemInf(models.Model) :
    PerdiqmaMemID = models.CharField(max_length=10, primary_key=True, default='')
    MemberName=models.TextField(max_length=200, null=True)
    StudID = models.ForeignKey('StudentUserLogin', on_delete=models.CASCADE)
    Position = models.TextField(max_length=20, null=True)

class DocumentSubmission(models.Model):
    STUDENT_CHOICES = [
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    ]

    student_name = models.CharField(max_length=225)
    document_title = models.CharField(max_length=225)
    document_file = models.FileField(upload_to='documents/')
    status = models.CharField(max_length=10, choices=STUDENT_CHOICES, default='pending')
    submission_date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.document_title 