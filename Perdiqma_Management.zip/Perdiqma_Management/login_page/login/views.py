from django.shortcuts import render, redirect
from .models import StudentUserLogin, PerdiqmaMemInf, LecturerUserLogin, DocumentSubmission
from django.contrib import messages
from django.http import HttpResponseRedirect

# Create your views here.

def LandingPage(request):
    return render(request, 'landing-page.html')

def SignupPageStudent(request):
    if request.method == 'POST':
        uname = request.POST.get('Username-Student')
        idd_Signup = request.POST.get('ID-SignUp-Student')
        password = request.POST.get('Password-SignUp-Student')

        try:
            # Check if the student ID already exists
            if StudentUserLogin.objects.filter(StudID=idd_Signup).exists():
                messages.error(request, 'Student ID already exists.')
                return redirect('SignupPageStudent')

            # Create a new student user
            Stud_User = StudentUserLogin(StudID=idd_Signup, StudPassword=password, StudName=uname)
            Stud_User.save()

            messages.success(request, 'Account created successfully. Please log in.')
            return redirect('LoginPage')
        except Exception as e:
            # Log the exception and show an error message
            print(f"Error: {e}")
            messages.error(request, 'An error occurred during the signup process. Please try again.')

    return render(request, 'dashboard-student.html')


def LoginPageStudent(request):
    if request.method == 'POST':
        stud_id = request.POST.get('Student-ID')
        password = request.POST.get('Password')
        
        try:
            # Attempt to get the user with the provided credentials
            login_instance = StudentUserLogin.objects.get(StudID=stud_id, StudPassword=password)
            
            # Set the session key based on the user's name
            request.session['user_fullname'] = login_instance.StudName
            
            # Redirect to the dashboard with the user's fullname
            return redirect('dashboard-student')
        except StudentUserLogin.DoesNotExist:
            messages.error(request, 'Invalid username or password. Please try again.')

    return render(request, 'dashboard-student.html')

def InformationFormPerdiqma(request):
    if request.methdod=='POST':
        MemberID = request.POST.get('Member-ID')
        MemberName = request.POST.get('Member-Name')
        StudentID = request.POST.get('Student-ID')
        PostionMem = request.POST.get('Position')

        Perdiqma_Member = PerdiqmaMemInf(PerdiqmaMemID=MemberID, MemberName=MemberName, StudID=StudentID, Position=PostionMem)
        Perdiqma_Member.save()

        return redirect('Menu')

    return render(request, 'menu_page.html')

def LandingToLoginStudent(request):
    return render(request, 'login-page-student.html')

def LandingToLoginLecturer(request):
    return render(request, 'login-page-lect.html')

def EventSubmissionBtn(request):
    return render(request, 'event-form.html')

def MemberRegistrationBtn(request):
    return render(request, 'Perdiqma-Member-Form.html')

def ImamBilalScheduleBtn(request):
    return render(request, 'imambilal-schedule.html')

def LogOutBtnStudent(request):
    return render(request, 'landing-page.html')

def SignupPageLecturer(request):
    if request.method == 'POST':
        unamelect = request.POST.get('Username-Lecturer')
        idd_Signup_lect = request.POST.get('ID-SignUp-Lecturer')
        passwordlect = request.POST.get('Password-SignUp-Lecturer')

        try:
            # Check if the lecturer ID already exists
            if LecturerUserLogin.objects.filter(LectID=idd_Signup_lect).exists():
                messages.error(request, 'Lecturer ID already exists.')
                return redirect('SignupPageLecturer')

            # Create a new lecturer user
            Lect_User = LecturerUserLogin(LectID=idd_Signup_lect, LectPassword=passwordlect, LectName=unamelect)
            Lect_User.save()

            messages.success(request, 'Account created successfully. Please log in.')
            return redirect('LecturerLogin')
        except Exception as e:
            # Log the exception and show an error message
            print(f"Error: {e}")
            messages.error(request, 'An error occurred during the signup process. Please try again.')

    return render(request, 'login-page-lect.html')

def LecturerDashboard(request):
    return render(request, 'dashboard-lecturer.html')

def LoginPageLecturer(request):
    if request.method == 'POST':
        lect_id = request.POST.get('ID-SignUp-Lecturer')
        password_lect = request.POST.get('Password-SignUp-Lecturer')
        
        try:
            # Attempt to get the user with the provided credentials
            login_instance = LecturerUserLogin.objects.get(LectID=lect_id, LectPassword=password_lect)
            
            # Set the session key based on the user's name
            request.session['user_fullname'] = login_instance.LectName
            
            # Redirect to the dashboard with the user's fullname
            return redirect('LecturerDashboard')
        except LecturerUserLogin.DoesNotExist:
            messages.error(request, 'Invalid username or password. Please try again.')

    return render(request, 'dashboard-lecturer.html')

def lecturer_dashboard(request):
    submissions = DocumentSubmission.objects.all()
    return render(request, 'lecturer_dashboard.html', {'submissions': submissions})

def approve_document(request, submission_id):
    submission = DocumentSubmission.objects.get(id=submission_id)
    submission.status = 'approved'
    submission.save()
    messages.success(request, 'Document approved successfully.')
    return redirect('lecturer_dashboard')

def reject_document(request, submission_id):
    submission = DocumentSubmission.objects.get(id=submission_id)
    submission.status = 'rejected'
    submission.save()
    messages.success(request, 'Document rejected successfully.')
    return redirect('lecturer_dashboard')

def EventFormLectBtn(request):
    return render(request, 'eventapproval-page.html')

def DetailInfoLectBtn(request):
    return render(request, 'Lecturer-Detail-Form.html')