from django.urls import path
from . import views

urlpatterns = [
    path("Dashboard/",views.SignupPageStudent, name="SignupPage"),
    path("LoginStudent/",views.LoginPageStudent, name="LoginPage"),
    path("Landingpage/",views.LandingPage, name=""),
    path("LecturerLogin/",views.LandingToLoginLecturer, name="Lecturer-Login-Page"),
    path("StudentLogin/",views.LandingToLoginStudent, name="Student-Login-Page"),
    path("Event Form/", views.EventSubmissionBtn, name="EventBtn"),
    path("RegistrationForm/", views.MemberRegistrationBtn, name="RegisterBtn"),
    path("Imam Bilal Schedule/", views.ImamBilalScheduleBtn, name="ImamBilalBtn"),
    path("Logout/", views.LogOutBtnStudent, name="LogoutStudent"),
    path("LecturerSignup/", views.SignupPageLecturer, name='SignupLecturer'),
    path("LecturerLogin/", views.LoginPageLecturer, name="LecturerLogin"),
    path("LecturerDashboard/", views.LecturerDashboard, name="LecturerDashboard"),
    path('lecturer/', views.lecturer_dashboard, name='lecturer_dashboard'),
    path('approve/<int:submission_id>/', views.approve_document, name='approve_document'),
    path('reject/<int:submission_id>/', views.reject_document, name='reject_document'),
    path("EventManagement/", views.EventFormLectBtn, name='EventApprovePageBtn'),
    path("LecturerInformationForm/", views.DetailInfoLectBtn, name='DetailInfoBtn')
]